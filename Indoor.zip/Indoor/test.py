import xml.etree.ElementTree as ET
import os

tree = ET.parse('C:/Users/Aysu/Desktop/Indoor Object Detection Dataset/annotation/annotation_s5.xml')

root = tree.getroot()

images = root.find("images")

width = 1280
height = 720


def get_class_id(class_name: str) -> int:
    classes = {
        "exit": 0,
        "fireextinguisher": 1,
        "chair": 2,
        "clock": 3,
        "trashbin": 4,
        "printer": 5,
        "screen": 6
    }

    return classes[class_name]


os.makedirs("labels", exist_ok=True)

for image in images.findall('image'):
    filename = image.get('file').split('.')[0] + ".txt"
    boxes = image.findall('box')
    with open(os.path.join("labels", filename), 'w') as f:
        for box in boxes:
            class_id = get_class_id(box.find('label').text)
            w = int(box.get('width')) / width
            h = int(box.get('height')) / height
            x_center = (int(box.get('left')) / width) + w / 2
            y_center = (int(box.get('top')) / height) + h / 2

            f.write(" ".join([str(i) for i in [class_id, x_center, y_center, w, h]]) + "\n")
